/**
 * =========================================================================================
 * SISTEMA DE RESERVAS, VALIDACIÓN QR Y ALMACENAMIENTO DE VOUCHERS EN GOOGLE DRIVE
 * COLEGIO MÉDICO DEL PERÚ - CONSEJO REGIONAL XX PASCO
 * CÓDIGO GOOGLE APPS SCRIPT (Backend para Google Sheets / Google Drive)
 * =========================================================================================
 * 
 * INSTRUCCIONES DE INSTALACIÓN:
 * 1. Crea una hoja de cálculo en Google Sheets (ejemplo: "Evento CMP Pasco 2026").
 * 2. Ve al menú: Extensiones -> Apps Script.
 * 3. Borra todo el código y pega este archivo completo.
 * 4. Haz clic en el botón azul "Implementar" (arriba a la derecha) -> "Nueva implementación".
 * 5. Selecciona el tipo de engranaje: "Aplicación web".
 * 6. Configura:
 *    - Descripción: "API Evento y Vouchers CMP Pasco"
 *    - Ejecutar como: "Yo (tu cuenta de correo)"
 *    - Quién tiene acceso: "Cualquier persona" (Anyone) -> ¡CLAVE PARA QUE FUNCIONE!
 * 7. Haz clic en "Implementar", autoriza los permisos y COPIA LA URL DE LA APLICACIÓN WEB.
 * 8. Pega esa URL en la pestaña "Ajustes" del sistema web.
 */

// Nombre de la pestaña de la hoja de cálculo y carpeta de Drive
const HOJA_REGISTROS = "Asistentes";
const CARPETA_VOUCHERS = "Vouchers Evento CMP Pasco 2026";

/**
 * Inicializar la hoja de cálculo con los encabezados oficiales si no existen
 */
function inicializarHoja() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(HOJA_REGISTROS);
  
  if (!sheet) {
    sheet = ss.insertSheet(HOJA_REGISTROS);
  }
  
  const headers = [
    "ID Reserva",
    "Fecha y Hora Registro",
    "N° CMP",
    "Nombres y Apellidos",
    "Celular / WhatsApp",
    "Correo Electrónico",
    "N° Acompañantes",
    "Nombres Acompañantes",
    "Estado Pago",
    "Monto Abonado (S/)",
    "Medio de Pago",
    "N° Operación",
    "Enlace Voucher Drive",
    "Estado Asistencia", // Titular: Pendiente / Ingresó
    "Fecha y Hora Ingreso",
    "Validado Por",
    "Código QR Titular",
    "Código QR Acompañante",
    "Estado Asistencia Acompañante", // Acompañante: Pendiente / Ingresó
    "Fecha y Hora Ingreso Acompañante",
    "Validado Por Acompañante"
  ];
  
  // Si la primera fila está vacía, agregar encabezados con estilo institucional Morado y Oro
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    
    // Dar formato visual a la cabecera (Morado Obispo y texto dorado)
    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setBackground("#380036");
    headerRange.setFontColor("#DFB76C");
    headerRange.setFontWeight("bold");
    headerRange.setHorizontalAlignment("center");
    headerRange.setVerticalAlignment("middle");
    sheet.setRowHeight(1, 38);
    sheet.setFrozenRows(1);
    
    // Auto-ajustar ancho de columnas
    for (let i = 1; i <= headers.length; i++) {
      sheet.autoResizeColumn(i);
    }
  }
}

/**
 * Guardar foto/captura del voucher en una carpeta específica de Google Drive
 */
function guardarVoucherEnGoogleDrive(base64Data, idReserva, cmp) {
  if (!base64Data || typeof base64Data !== "string" || !base64Data.includes("base64,")) {
    return "";
  }
  
  try {
    let folder;
    const folders = DriveApp.getFoldersByName(CARPETA_VOUCHERS);
    if (folders.hasNext()) {
      folder = folders.next();
    } else {
      folder = DriveApp.createFolder(CARPETA_VOUCHERS);
      folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    }
    
    // Extraer MIME type y bytes
    const parts = base64Data.split("base64,");
    const mimeMatch = parts[0].match(/:(.*?);/);
    const mimeType = mimeMatch ? mimeMatch[1] : "image/jpeg";
    const extension = mimeType.includes("png") ? ".png" : ".jpg";
    const decodedBytes = Utilities.base64Decode(parts[1]);
    const fileName = "Voucher_CMP_" + (cmp || "00000") + "_" + idReserva + extension;
    
    const blob = Utilities.newBlob(decodedBytes, mimeType, fileName);
    const file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    
    return file.getUrl();
  } catch (err) {
    Logger.log("Error al subir voucher a Google Drive: " + err);
    return "";
  }
}

/**
 * Manejador de solicitudes GET (Consulta de datos, verificación de QR o prueba de conexión)
 */
function doGet(e) {
  try {
    inicializarHoja();
    const action = e.parameter ? e.parameter.action : null;
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(HOJA_REGISTROS);
    
    // 1. Obtener todos los asistentes
    if (action === "obtenerAsistentes" || !action) {
      const data = sheet.getDataRange().getValues();
      if (data.length <= 1) {
        return jsonResponse({ success: true, data: [] });
      }
      
      const headers = data[0];
      const rows = data.slice(1);
      const asistentes = rows.map((row, index) => {
        let obj = { rowIndex: index + 2 };
        headers.forEach((header, i) => {
          obj[header] = row[i];
        });
        return obj;
      });
      
      return jsonResponse({ success: true, data: asistentes });
    }
    
    // 2. Ping de prueba de conexión
    if (action === "ping") {
      return jsonResponse({
        success: true,
        mensaje: "Conexión exitosa con Google Sheets & Drive - CMP Pasco",
        fecha: new Date().toISOString()
      });
    }
    
    return jsonResponse({ success: true, mensaje: "API Activa" });
  } catch (error) {
    return jsonResponse({ success: false, error: error.toString() });
  }
}

/**
 * Manejador de solicitudes POST (Registrar asistencia, validar QR y subir vouchers a Drive)
 */
function doPost(e) {
  const lock = LockService.getScriptLock();
  
  try {
    lock.waitLock(15000);
    inicializarHoja();
    
    let body = {};
    if (e.postData && e.postData.contents) {
      body = JSON.parse(e.postData.contents);
    }
    
    const action = body.action || "registrar";
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(HOJA_REGISTROS);
    
    // =========================================================================
    // ACCIÓN 1: REGISTRAR ASISTENTE Y SUBIR VOUCHER A GOOGLE DRIVE
    // =========================================================================
    if (action === "registrar") {
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      const rows = data.slice(1);
      
      const cmpIndex = headers.indexOf("N° CMP");
      const idIndex = headers.indexOf("ID Reserva");
      const nuevoCMP = String(body.cmp || "").trim();
      const idReserva = body.idReserva || "CMP-" + Utilities.formatDate(new Date(), "America/Lima", "yyyyMMdd-") + Math.floor(1000 + Math.random() * 9000);
      const numAcomp = parseInt(body.acompanantes || 0);
      
      // Comprobar si ya existe la reserva por CMP o ID Reserva
      let existingRowIndex = -1;
      if (nuevoCMP || body.idReserva) {
        for (let i = 0; i < rows.length; i++) {
          const matchCMP = nuevoCMP && String(rows[i][cmpIndex]).trim() === nuevoCMP;
          const matchID = body.idReserva && String(rows[i][idIndex]).trim() === String(body.idReserva).trim();
          if (matchCMP || matchID) {
            existingRowIndex = i + 2;
            break;
          }
        }
      }
      
      // Si la reserva ya existe y viene una actualización de voucher o aprobación de pago:
      if (existingRowIndex !== -1) {
        let enlaceVoucherDrive = "";
        if (numAcomp > 0 && body.voucherImg) {
          enlaceVoucherDrive = guardarVoucherEnGoogleDrive(body.voucherImg, idReserva, nuevoCMP);
        }
        
        const voucherCol = headers.indexOf("Enlace Voucher Drive") + 1;
        const estadoPagoCol = headers.indexOf("Estado Pago") + 1;
        const nroOpCol = headers.indexOf("N° Operación") + 1;
        const qrAcompCol = headers.indexOf("Código QR Acompañante") + 1;
        const acompCol = headers.indexOf("N° Acompañantes") !== -1 ? headers.indexOf("N° Acompañantes") + 1 : headers.indexOf("Nº Acompañantes") + 1;
        const nomAcompCol = headers.indexOf("Nombres Acompañantes") + 1;
        const montoCol = headers.indexOf("Monto Abonado (S/)") + 1;
        const metodoCol = headers.indexOf("Medio de Pago") + 1;
        
        if (enlaceVoucherDrive && voucherCol > 0) {
          sheet.getRange(existingRowIndex, voucherCol).setValue(enlaceVoucherDrive);
        }
        if (body.estadoPago && estadoPagoCol > 0) {
          sheet.getRange(existingRowIndex, estadoPagoCol).setValue(body.estadoPago);
        }
        if (body.nroOperacion && nroOpCol > 0) {
          sheet.getRange(existingRowIndex, nroOpCol).setValue(body.nroOperacion);
        }
        if (numAcomp > 0) {
          if (acompCol > 0) sheet.getRange(existingRowIndex, acompCol).setValue(numAcomp);
          if (nomAcompCol > 0 && body.nombresAcompanantes) sheet.getRange(existingRowIndex, nomAcompCol).setValue(body.nombresAcompanantes);
          if (qrAcompCol > 0) sheet.getRange(existingRowIndex, qrAcompCol).setValue(body.qrAcompanante || (idReserva + "-ACOMP1"));
          if (montoCol > 0 && body.montoPago) sheet.getRange(existingRowIndex, montoCol).setValue(body.montoPago);
          if (metodoCol > 0 && body.metodoPago) sheet.getRange(existingRowIndex, metodoCol).setValue(body.metodoPago);
        }
        
        return jsonResponse({
          success: true,
          mensaje: "Reserva existente actualizada con nuevo comprobante / estado en Google Drive",
          idReserva: idReserva,
          enlaceVoucherDrive: enlaceVoucherDrive
        });
      }
      
      const fechaRegistro = body.fechaRegistro || Utilities.formatDate(new Date(), "America/Lima", "yyyy-MM-dd HH:mm:ss");
      const qrTitular = body.qrTitular || body.qrHash || idReserva + "-" + nuevoCMP;
      const qrAcompanante = numAcomp > 0 ? (body.qrAcompanante || idReserva + "-ACOMP1") : "";
      
      // Subir voucher a Google Drive si existe
      let enlaceVoucherDrive = "";
      if (numAcomp > 0 && body.voucherImg) {
        enlaceVoucherDrive = guardarVoucherEnGoogleDrive(body.voucherImg, idReserva, nuevoCMP);
      }
      
      const estadoPago = body.estadoPago || (numAcomp > 0 ? "Pendiente" : "Gratuito");
      const montoAbonado = body.montoPago || (numAcomp > 0 ? numAcomp * 20 : 0);
      const metodoPago = body.metodoPago || (numAcomp > 0 ? "Yape" : "Gratuito (Titular)");
      const nroOperacion = body.nroOperacion || (numAcomp > 0 ? "" : "N/A");
      
      const nuevaFila = [
        idReserva,
        fechaRegistro,
        nuevoCMP,
        body.nombres || "",
        body.celular || "",
        body.correo || "",
        numAcomp,
        body.nombresAcompanantes || (numAcomp > 0 ? "Acompañante Registrado" : "Ninguno"),
        estadoPago,
        montoAbonado,
        metodoPago,
        nroOperacion,
        enlaceVoucherDrive,
        "Pendiente", // Estado Asistencia Titular
        "",          // Fecha ingreso Titular
        "",          // Validado por Titular
        qrTitular,
        qrAcompanante,
        numAcomp > 0 ? "Pendiente" : "", // Estado Asistencia Acompanante
        "",                              // Fecha ingreso Acompanante
        ""                               // Validado por Acompanante
      ];
      
      sheet.appendRow(nuevaFila);
      
      return jsonResponse({
        success: true,
        mensaje: "Reserva registrada con pases duales en Google Drive",
        idReserva: idReserva,
        qrTitular: qrTitular,
        qrAcompanante: qrAcompanante,
        enlaceVoucherDrive: enlaceVoucherDrive
      });
    }
    
    // =========================================================================
    // ACCIÓN 2: VALIDAR INGRESO EN PUERTA (TITULAR O ACOMPAÑANTE)
    // =========================================================================
    if (action === "validarIngreso") {
      const codigo = String(body.codigo || "").trim();
      const validador = body.validador || "Staff Puerta";
      const esAcompScan = codigo.toLowerCase().includes("acomp");
      
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      const rows = data.slice(1);
      
      const idIndex = headers.indexOf("ID Reserva");
      const cmpIndex = headers.indexOf("N° CMP");
      const qrTitIndex = headers.indexOf("Código QR Titular") !== -1 ? headers.indexOf("Código QR Titular") : headers.indexOf("Código QR / Hash");
      const qrAcompIndex = headers.indexOf("Código QR Acompañante");
      const estadoIndex = headers.indexOf("Estado Asistencia");
      const fechaIngresoIndex = headers.indexOf("Fecha y Hora Ingreso");
      const validadorIndex = headers.indexOf("Validado Por");
      const estadoPagoIndex = headers.indexOf("Estado Pago");
      const estadoAcompIndex = headers.indexOf("Estado Asistencia Acompañante");
      const fechaIngresoAcompIndex = headers.indexOf("Fecha y Hora Ingreso Acompañante");
      const validadorAcompIndex = headers.indexOf("Validado Por Acompañante");
      
      let filaIndex = -1;
      let rowData = null;
      
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        if (esAcompScan) {
          if (
            (qrAcompIndex !== -1 && String(row[qrAcompIndex]).trim() === codigo) ||
            String(row[idIndex]).trim() + "-ACOMP1" === codigo ||
            String(row[idIndex]).trim() + "-ACOMP" === codigo
          ) {
            filaIndex = i + 2;
            rowData = row;
            break;
          }
        } else {
          if (
            String(row[idIndex]).trim() === codigo ||
            (qrTitIndex !== -1 && String(row[qrTitIndex]).trim() === codigo) ||
            String(row[cmpIndex]).trim() === codigo
          ) {
            filaIndex = i + 2;
            rowData = row;
            break;
          }
        }
      }
      
      if (filaIndex === -1) {
        return jsonResponse({
          success: false,
          estado: "NO_ENCONTRADO",
          mensaje: "El código no corresponde a ninguna reserva registrada."
        });
      }
      
      const horaIngreso = Utilities.formatDate(new Date(), "America/Lima", "yyyy-MM-dd HH:mm:ss");

      // Validar acompañante
      if (esAcompScan) {
        const estadoPago = estadoPagoIndex !== -1 ? rowData[estadoPagoIndex] : "Pendiente";
        if (estadoPago !== "Aprobado" && estadoPago !== "Pagado") {
          return jsonResponse({
            success: false,
            estado: "PAGO_PENDIENTE",
            mensaje: "⚠️ El pago del acompañante aún no ha sido APROBADO por administración.",
            asistente: {
              idReserva: rowData[idIndex],
              nombres: rowData[headers.indexOf("Nombres y Apellidos")],
              cmp: rowData[cmpIndex]
            }
          });
        }

        const estadoAcomp = estadoAcompIndex !== -1 ? rowData[estadoAcompIndex] : "Pendiente";
        if (estadoAcomp === "Ingresó" || estadoAcomp === "Asistió") {
          return jsonResponse({
            success: true,
            estado: "YA_INGRESADO",
            esAcompanante: true,
            mensaje: "¡ALERTA! El boleto de Acompañante YA FUE VALIDADO previamente.",
            fechaPrimerIngreso: fechaIngresoAcompIndex !== -1 ? rowData[fechaIngresoAcompIndex] : "",
            validadoPor: validadorAcompIndex !== -1 ? rowData[validadorAcompIndex] : "",
            asistente: {
              idReserva: rowData[idIndex],
              nombres: rowData[headers.indexOf("Nombres y Apellidos")],
              cmp: rowData[cmpIndex]
            }
          });
        }

        if (estadoAcompIndex !== -1) sheet.getRange(filaIndex, estadoAcompIndex + 1).setValue("Ingresó");
        if (fechaIngresoAcompIndex !== -1) sheet.getRange(filaIndex, fechaIngresoAcompIndex + 1).setValue(horaIngreso);
        if (validadorAcompIndex !== -1) sheet.getRange(filaIndex, validadorAcompIndex + 1).setValue(validador);

        return jsonResponse({
          success: true,
          estado: "VALIDO",
          esAcompanante: true,
          mensaje: "¡Ingreso de Acompañante autorizado con éxito!",
          horaIngreso: horaIngreso,
          asistente: {
            idReserva: rowData[idIndex],
            nombres: rowData[headers.indexOf("Nombres y Apellidos")],
            cmp: rowData[cmpIndex],
            horaIngreso: horaIngreso
          }
        });
      }

      // Validar titular
      const estadoActual = rowData[estadoIndex];
      if (estadoActual === "Ingresó" || estadoActual === "Asistió") {
        return jsonResponse({
          success: true,
          estado: "YA_INGRESADO",
          esAcompanante: false,
          mensaje: "¡ALERTA! Este boleto Titular YA FUE VALIDADO previamente.",
          fechaPrimerIngreso: rowData[fechaIngresoIndex],
          validadoPor: rowData[validadorIndex],
          asistente: {
            idReserva: rowData[idIndex],
            nombres: rowData[headers.indexOf("Nombres y Apellidos")],
            cmp: rowData[cmpIndex]
          }
        });
      }
      
      // Registrar ingreso titular
      sheet.getRange(filaIndex, estadoIndex + 1).setValue("Ingresó");
      sheet.getRange(filaIndex, fechaIngresoIndex + 1).setValue(horaIngreso);
      sheet.getRange(filaIndex, validadorIndex + 1).setValue(validador);
      
      return jsonResponse({
        success: true,
        estado: "VALIDO",
        esAcompanante: false,
        mensaje: "¡Ingreso Titular autorizado con éxito!",
        horaIngreso: horaIngreso,
        asistente: {
          idReserva: rowData[idIndex],
          nombres: rowData[headers.indexOf("Nombres y Apellidos")],
          cmp: rowData[cmpIndex],
          horaIngreso: horaIngreso
        }
      });
    }
    
    // =========================================================================
    // ACCIÓN 3: RESTABLECER ASISTENCIA A PENDIENTE (ADMIN)
    // =========================================================================
    if (action === "reiniciarAsistencia") {
      const codigo = String(body.codigo || "").trim();
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      const rows = data.slice(1);
      
      const idIndex = headers.indexOf("ID Reserva");
      const estadoIndex = headers.indexOf("Estado Asistencia");
      const fechaIngresoIndex = headers.indexOf("Fecha y Hora Ingreso");
      const validadorIndex = headers.indexOf("Validado Por");
      
      for (let i = 0; i < rows.length; i++) {
        if (String(rows[i][idIndex]).trim() === codigo) {
          const fila = i + 2;
          sheet.getRange(fila, estadoIndex + 1).setValue("Pendiente");
          sheet.getRange(fila, fechaIngresoIndex + 1).setValue("");
          sheet.getRange(fila, validadorIndex + 1).setValue("");
          return jsonResponse({ success: true, mensaje: "Estado restablecido a Pendiente." });
        }
      }
      return jsonResponse({ success: false, mensaje: "Registro no encontrado." });
    }

    // =========================================================================
    // ACCIÓN 4: ELIMINAR REGISTRO DE ASISTENTE EN GOOGLE SHEETS
    // =========================================================================
    if (action === "eliminarAsistente" || action === "eliminar") {
      const idReserva = String(body.idReserva || body.codigo || "").trim();
      const cmp = String(body.cmp || "").trim();
      
      const data = sheet.getDataRange().getValues();
      const headers = data[0];
      const rows = data.slice(1);
      
      const idIndex = headers.indexOf("ID Reserva");
      const cmpIndex = headers.indexOf("N° CMP");
      
      let filaEliminar = -1;
      for (let i = 0; i < rows.length; i++) {
        const matchId = idReserva && String(rows[i][idIndex]).trim() === idReserva;
        const matchCmp = cmp && String(rows[i][cmpIndex]).trim() === cmp;
        if (matchId || matchCmp) {
          filaEliminar = i + 2;
          break;
        }
      }
      
      if (filaEliminar !== -1) {
        sheet.deleteRow(filaEliminar);
        return jsonResponse({
          success: true,
          mensaje: "Registro eliminado exitosamente de la hoja de Google Sheets.",
          idReserva: idReserva
        });
      }
      
      return jsonResponse({
        success: false,
        mensaje: "No se encontró el registro para eliminar en Google Sheets."
      });
    }
    
    return jsonResponse({ success: false, mensaje: "Acción no reconocida." });
    
  } catch (error) {
    return jsonResponse({ success: false, error: error.toString() });
  } finally {
    lock.releaseLock();
  }
}

/**
 * Función auxiliar para responder JSON con cabeceras CORS
 */
function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
